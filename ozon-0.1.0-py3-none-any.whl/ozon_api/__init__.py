from ozon_api.api import Ozon

__all__ = ['Ozon']
