import requests
import json
from datetime import datetime, timedelta
import os
from dotenv import find_dotenv, load_dotenv


class Ozon:
    __instance = None

    # price = 0
    # sale_commission = 0
    # processing_and_delivery = 0

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super().__new__(cls)
        return cls.__instance

    def __del__(self):
        Ozon.__instance = None

    def __init__(self, api_key, client_id):
        self.api_key = api_key
        self.client_id = client_id
        self.session = requests.Session()
        self.session.headers = {
            'Api-Key': self.api_key,
            'Client-Id': self.client_id,
        }

    def get_orders(self):
        data = {
            "dir": "ASC",
            "filter": {
                "cutoff_from": self.convert_time(from_date=True),
                "cutoff_to": self.convert_time(to_date=True),
                "delivery_method_id": [],
                "provider_id": [],
                "status": "awaiting_deliver",
                "warehouse_id": []
            },
            "limit": 100,
            "offset": 0,
            "with": {
                "analytics_data": True,
                "barcodes": True,
                "financial_data": True,
                "translit": True
            }
        }
        response = self.session.post(
            'https://api-seller.ozon.ru/v3/posting/fbs/unfulfilled/list',
            data=json.dumps(data)
        )

        return json.loads(response.content)

    @staticmethod
    def convert_time(from_date=None, to_date=None):
        date = datetime.today()
        if from_date:
            return date.strftime('%Y-%m-%dT%H:%M:%SZ')
        return (date + timedelta(days=30)).strftime('%Y-%m-%dT%H:%M:%SZ')

    def get_finance(self, order):
        data = {
            "date": {
                "from": self.convert_time(from_date=True),
                "to": self.convert_time(to_date=True)
            },
            "posting_number": order,
            "transaction_type": "all"
        }
        response = self.session.post(
            'https://api-seller.ozon.ru/v3/finance/transaction/totals',
            data=json.dumps(data),
        )
        finance = json.loads(response.content)
        self.price = finance['result']['accruals_for_sale']
        self.sale_commission = finance['result']['sale_commission']
        self.processing_and_delivery = finance['result']['processing_and_delivery']
        # return json.loads(response.content)

    def test(self):
        data = {
            "dir": "ASC",
            "filter": {
                "since": "2022-10-01T00:00:00.000Z",
                "status": "delivered",
                "to": "2023-02-20T23:59:59.000Z"
            },
            "limit": 100,
            "offset": 0,
            "translit": True,
            "with": {
                "analytics_data": True,
                "financial_data": True,
            }
        }
        response = self.session.post(
            'https://api-seller.ozon.ru/v3/posting/fbs/list',
            data=json.dumps(data),
        )
        return json.loads(response.content)

    def get_order(self, order_number):
        data = {
            "posting_number": order_number,
            "with": {
                "analytics_data": False,
                "barcodes": False,
                "financial_data": False,
                "product_exemplars": False,
                "translit": False,
            }
        }
        response = self.session.post(
            'https://api-seller.ozon.ru/v3/posting/fbs/get',
            data=json.dumps(data),
        )
        order_data = json.loads(response.content)
        self.price = float(order_data['result']['products'][0]['price'])


if __name__ == '__main__':
    load_dotenv(find_dotenv())
    test = Ozon(os.getenv('OZON_API'), os.getenv('CLIENT_ID'))
    a = test.get_finance('45911497-0021-1')
    print(a)
